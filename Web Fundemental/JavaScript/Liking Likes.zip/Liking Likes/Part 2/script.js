var x = [document.querySelector('#change-number0'),document.querySelector('#change-number1'),document.querySelector('#change-number2')]
var h = [9, 12, 9];
console.log(i);
function like0() {
    h[0]++;
    x[0].innerText = h[0];
}
function like1() {
    h[1]++;
    x[1].innerText = h[1];
}
function like2() {
    h[2]++;
    x[2].innerText = h[2];
}