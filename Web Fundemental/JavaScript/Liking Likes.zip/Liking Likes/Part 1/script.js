var i = document.querySelector('#change-number')
var h = 1;
console.log(i);
function like() {
    h++;
    i.innerText = h;
}