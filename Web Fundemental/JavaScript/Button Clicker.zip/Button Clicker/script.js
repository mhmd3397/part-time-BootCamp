function login(element) {
        element.innerText = "Logout";
}
function hide(target) {
    target.remove();
}

